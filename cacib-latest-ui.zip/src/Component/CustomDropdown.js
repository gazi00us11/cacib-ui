import React, { useState, useRef, useEffect } from 'react';
 
// --- Reusable Helper: Custom Dropdown Arrow SVG ---
const DropdownArrow = ({ isOpen }) => (
  <svg
    height="20"
    width="20"
    viewBox="0 0 20 20"
    aria-hidden="true"
    focusable="false"
    style={{
      color: '#333',
      transition: 'transform 0.2s ease',
      transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)',
    }}
  >
    <path d="M4.516 7.548c0.436-0.446 1.043-0.481 1.576 0l3.908 3.747 3.908-3.747c0.533-0.481 1.141-0.446 1.574 0 0.436 0.445 0.408 1.197 0 1.615l-4.695 4.502c-0.533 0.481-1.408 0.481-1.942 0l-4.695-4.502c-0.408-0.418-0.436-1.17 0-1.615z"></path>
  </svg>
);
 
// --- Custom Dropdown Component ---
const CustomDropdown = ({ options, selectedValue, onChange, placeholder }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [hoveredOption, setHoveredOption] = useState(null);
  const dropdownRef = useRef(null);
 
  // Effect to close dropdown if clicked outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);
 
  const handleOptionClick = (option) => {
    onChange(option);
    setIsOpen(false);
  };
 
  // --- Styles for the Custom Dropdown ---
  const dropdownStyle = {
    position: 'relative',
    width: '100%',
    color: '#333',
  };
 
  const dropdownHeaderStyle = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '12px 16px',
    backgroundColor: '#f7f7fa',
    border: '1px solid #dcdcdc',
    borderRadius: '8px',
    cursor: 'pointer',
    fontSize: '16px',
  };
 
  const optionsContainerStyle = {
    position: 'absolute', // To float over content below if needed, but in this layout it pushes content down
    width: '100%',
    marginTop: '4px',
    backgroundColor: '#ffffff',
    border: '1px solid #dcdcdc',
    borderRadius: '8px',
    overflow: 'hidden',
    boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
    zIndex: 10 // Ensure it appears above other elements if necessary
  };
 
  const optionStyle = {
    padding: '12px 16px',
    cursor: 'pointer',
    fontSize: '16px',
    borderBottom: '1px solid #f0f0f0'
  };
 
  return (
    <div ref={dropdownRef} style={dropdownStyle}>
      <div style={dropdownHeaderStyle} onClick={() => setIsOpen(!isOpen)}>
        <span>{selectedValue || placeholder}</span>
        <DropdownArrow isOpen={isOpen} />
      </div>
 
      {isOpen && (
        <div style={optionsContainerStyle}>
          {options.map((option, index) => (
            <div
              key={option}
              style={{
                ...optionStyle,
                backgroundColor: hoveredOption === option ? '#f0f2f5' : '#ffffff',
                borderBottom: index === options.length - 1 ? 'none' : optionStyle.borderBottom,
              }}
              onClick={() => handleOptionClick(option)}
              onMouseEnter={() => setHoveredOption(option)}
              onMouseLeave={() => setHoveredOption(null)}
            >
              {option}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
 
export default CustomDropdown;