import React, { useState, useEffect } from 'react';
import './UserFlow.css';
import decisionTreeData from '../Data/decisionTreeJson.json';
import { useNavigate } from 'react-router-dom';

const Questionnaire = () => {
  const navigate = useNavigate();
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [isCompleted, setIsCompleted] = useState(false);
  const [selectedRequirements, setSelectedRequirements] = useState([]);

  useEffect(() => {
    const extractedQuestions = extractQuestions(decisionTreeData);
    setQuestions(extractedQuestions);
  }, []);

  const extractQuestions = (node) => {
    let questions = [];

    const traverse = (node) => {
      if (node.children) {
        const hasYesNo = node.children.some(child =>
          child.name === 'Yes' || child.name === 'No'
        );

        if (hasYesNo) {
          questions.push({
            id: questions.length,
            question: node.name
          });
        }

        node.children.forEach(child => traverse(child));
      }
    };

    traverse(node);
    return questions;
  };

  const handleAnswer = (questionId, answer) => {
    const newAnswers = {
      ...answers,
      [questionId]: answer
    };
    setAnswers(newAnswers);

    if (Object.keys(newAnswers).length === questions.length) {
      const requirements = collectRequirements(newAnswers);
      setSelectedRequirements(requirements);
      setIsCompleted(true);
    }
  };

  const collectRequirements = (allAnswers) => {
    const requirements = [];

    questions.forEach(question => {
      const answer = allAnswers[question.id];
      if (answer) {
        const requirement = findRequirement(decisionTreeData, question.question, answer);
        if (requirement) {
          requirements.push({
            question: question.question,
            answer: answer,
            requirement: requirement
          });
        }
      }
    });

    return requirements;
  };

  const findRequirement = (node, questionText, answer) => {
    if (node.name === questionText && node.children) {
      const answerNode = node.children.find(child => child.name === answer);
      if (answerNode && answerNode.requirements) {
        return answerNode.requirements;
      }
    }

    if (node.children) {
      for (let child of node.children) {
        const result = findRequirement(child, questionText, answer);
        if (result) return result;
      }
    }

    return null;
  };

  const handleRestart = () => {
    setAnswers({});
    setIsCompleted(false);
    setSelectedRequirements([]);
  };

  const handleHome = () => {
    navigate('/');
  };

  const getNextUnansweredQuestionIndex = () => {
    return questions.findIndex(q => !answers.hasOwnProperty(q.id));
  };

  if (isCompleted) {
    return (
      <div className="screen-flow-container">
        <div className="header">
          <span className="logo">KYC</span>
          <h2>Questionnaire Results</h2>
          <span className="logo-end">Requirements</span>
        </div>

        <div className="navigation-controls">
          <button onClick={handleRestart} className="back-btn-global">
            Start Over
          </button>
          <button onClick={handleHome} className="back-btn-global">
            Home
          </button>
        </div>

        <div className="completion-page-container single-view-fade-in">
          <div className="completion-header">
            Selected Requirements Based on Your Answers
          </div>

          <div className="completion-answers-container">
            {selectedRequirements.length > 0 ? (
              <ul className="completion-list">
                {selectedRequirements.map((item, index) => (
                  <li key={index} className="completion-list-item">
                    <strong>{item.question}</strong> ({item.answer}): {item.requirement}
                  </li>
                ))}
              </ul>
            ) : (
              <p>No specific requirements found for your selections.</p>
            )}
          </div>
          <div className="completion-footer">
            <div className="completion-down-arrow"></div>
            <div className="completion-buttons">
              <button className="kyc-checklist-btn">KYC Checklist</button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (questions.length === 0) {
    return <div>Loading questions...</div>;
  }

  const nextQuestionIndex = getNextUnansweredQuestionIndex();

  return (
    <div className="screen-flow-container">
      <div className="header">
        <span className="logo">KYC</span>
        <h2>Decision Tree Questionnaire</h2>
        <span className="logo-end">Questions</span>
      </div>

      <div className="navigation-controls">
        <button onClick={handleRestart} className="back-btn-global">
          Restart
        </button>
        <button onClick={handleHome} className="back-btn-global">
          Home
        </button>
      </div>

      <div className="question-display-area">
        <div style={{ width: '100%', padding: '0 2rem' }}>
          {questions.map((question, index) => {
            const isAnswered = answers.hasOwnProperty(question.id);
            const isCurrentQuestion = index === nextQuestionIndex;

            if (!isAnswered && !isCurrentQuestion) return null;

            return (
              <div key={question.id} style={{
                width: '100%',
                marginBottom: '1rem',
                border: '1px solid #ddd',
                borderRadius: '8px',
                padding: '1rem'
              }}>
                <div style={{
                  fontSize: '0.9rem',
                  color: '#666',
                  marginBottom: '0.5rem'
                }}>
                  Question {index + 1} of {questions.length}
                </div>

                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  gap: '2rem'
                }}>
                  <h3 style={{
                    margin: 0,
                    color: '#333',
                    fontSize: '1.1rem',
                    flex: 1
                  }}>
                    {question.question}
                  </h3>

                  <div style={{
                    display: 'flex',
                    gap: '1rem',
                    flexShrink: 0
                  }}>
                    <button
                      onClick={() => handleAnswer(question.id, 'Yes')}
                      style={{
                        padding: '0.5rem 2rem',
                        border: '2px solid #28a745',
                        borderRadius: '6px',
                        backgroundColor: answers[question.id] === 'Yes' ? '#28a745' : 'white',
                        color: answers[question.id] === 'Yes' ? 'white' : '#28a745',
                        cursor: 'pointer',
                        fontWeight: '600',
                        fontSize: '1rem'
                      }}
                    >
                      Yes
                    </button>

                    <button
                      onClick={() => handleAnswer(question.id, 'No')}
                      style={{
                        padding: '0.5rem 2rem',
                        border: '2px solid #dc3545',
                        borderRadius: '6px',
                        backgroundColor: answers[question.id] === 'No' ? '#dc3545' : 'white',
                        color: answers[question.id] === 'No' ? 'white' : '#dc3545',
                        cursor: 'pointer',
                        fontWeight: '600',
                        fontSize: '1rem'
                      }}
                    >
                      No
                    </button>
                  </div>
                </div>

                {isAnswered && (
                  <div style={{
                    marginTop: '0.5rem',
                    color: '#666',
                    fontSize: '0.8rem'
                  }}>
                    Answered: {answers[question.id]} (Click to change)
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};

export default Questionnaire;
