import React, { useState } from 'react';
import './UserFlow.css';
import { useNavigate } from 'react-router-dom';

const UserFlow = () => {
    const navigate = useNavigate();
    const [activeQuestion, setActiveQuestion] = useState(1);
    const [answers, setAnswers] = useState({});
    const [kiwiId, setKiwiId] = useState('');

    const allQuestions = getAllQuestions();
    const currentStep = getStepForQuestion(activeQuestion, allQuestions);
    const maxQuestionId = Math.max(...allQuestions.map(q => q.id));

    const handleAnswer = (id, answer) => {
        setAnswers(prev => ({ ...prev, [id]: answer }));
        if (id !== 3) {
            setActiveQuestion(prev => prev + 1);
        }
    };

    const handleKiwiSubmit = () => {
        if (kiwiId.trim() !== '') {
            setAnswers(prev => ({ ...prev, 3: kiwiId }));
        }
    };

    const handleAdvanceAfterKiwi = () => {
        setActiveQuestion(4);
    };

    const handleBack = () => {
        if (activeQuestion > 1) {
            const prevQuestion = activeQuestion - 1;
            const { [prevQuestion]: _, ...remainingAnswers } = answers;
            setAnswers(remainingAnswers);
            setActiveQuestion(prevQuestion);
            if (prevQuestion === 3) {
                setKiwiId('');
            }
        }
    };


    const handleMultiSelectAnswer = (id, answer) => {
        setAnswers(prev => ({ ...prev, [id]: answer }));
    };

    const advanceToNextQuestion = () => {
        const nextQuestion = allQuestions.find(q => q.id > activeQuestion);
        if (nextQuestion) {
            setActiveQuestion(nextQuestion.id);
        } else {
            setActiveQuestion(maxQuestionId + 1); // Go to completion
        }
    };

    const renderStepContent = () => {
        const questionsForStep = allQuestions.filter(q => q.step === currentStep);

        if (currentStep === 1) {
            const processQ = questionsForStep.find(q => q.id === 1);
            const entityQ = questionsForStep.find(q => q.id === 2);
            const kiwiIdQ = questionsForStep.find(q => q.id === 3);

            return (
                <div className="step1-design-container single-view-fade-in">
                    <div className="step1-main-flow">
                        <div className="step1-question-column">
                            <div className="box-title-tab">{processQ.tabTitle}</div>
                            <QuestionCard question={processQ} onAnswer={handleAnswer} answers={answers} activeQuestion={activeQuestion} />
                        </div>

                        {activeQuestion >= 2 && <div className="step1-flow-arrow"></div>}

                        <div className="step1-question-column">
                            {activeQuestion >= 2 && <>
                                <div className="box-title-tab">{entityQ.tabTitle}</div>
                                <QuestionCard question={entityQ} onAnswer={handleAnswer} answers={answers} activeQuestion={activeQuestion} />
                            </>}
                        </div>


                        {activeQuestion >= 3 && <div className="step1-flow-arrow"></div>}

                        <div className="step1-question-column">
                            {activeQuestion >= 3 && <>
                                <div className="box-title-tab">{kiwiIdQ.tabTitle}</div>
                                <QuestionCard question={kiwiIdQ} onAnswer={handleAnswer} setKiwiId={setKiwiId} onSubmitKiwi={handleKiwiSubmit} kiwiId={kiwiId} answers={answers} activeQuestion={activeQuestion} />
                            </>}
                        </div>
                    </div>
                    {answers[3] && (
                        <div className="step1-risk-rating-flow">
                            <div className="step1-down-arrow"></div>
                            <div className="step1-risk-rating-box">
                                <div className="risk-rating-title">Risk Rating of the Kiwis ID</div>
                                <div className="risk-rating-content">
                                    <div className="risk-rating-field">Kiwi ID = {answers[3]}</div>
                                    <div className="risk-rating-field-highlight">Risk Rating [A]</div>
                                </div>
                            </div>
                            <div className="step1-button-container">
                                <button className="next-step-btn" onClick={handleAdvanceAfterKiwi}>Next Step</button>
                            </div>
                        </div>
                    )}
                </div>
            );
        }

        return (
            <div className="step-container single-view-fade-in">
                {questionsForStep.map((q, index) => (
                    <React.Fragment key={q.id}>
                        {index > 0 && activeQuestion >= q.id && <div className="step1-flow-arrow"></div>}
                        {activeQuestion >= q.id && (
                            <div className={`question-wrapper ${q.layout === 'full-width-grid' ? 'full-width-wrapper' : ''}`}>
                                <div className="box-title-tab">{q.tabTitle}</div>
                                <QuestionCard
                                    question={q}
                                    onAnswer={handleAnswer}
                                    onMultiSelectAnswer={handleMultiSelectAnswer}
                                    onAdvance={advanceToNextQuestion}
                                    answers={answers}
                                    activeQuestion={activeQuestion}
                                />
                            </div>
                        )}
                    </React.Fragment>
                ))}
            </div>
        );
    };

    if (activeQuestion > maxQuestionId) {
        return (
            <div className="completion-page-container single-view-fade-in">
                <div className="navigation-controls">
                    <button onClick={handleBack} className="back-btn-global">Back</button>
                </div>
                <div className="completion-header">
                    Below are the list of selection made
                </div>
                <div className="completion-answers-container">
                    <ul className="completion-list">
                        {Object.entries(answers).sort(([a], [b]) => a - b).map(([qId, ans]) => {
                            const question = allQuestions.find(q => q.id === parseInt(qId));
                            const answerText = Array.isArray(ans) ? ans.join(', ') : ans;
                            return (
                                <li key={qId} className="completion-list-item">
                                    <strong>{question.title}:</strong> {answerText}
                                </li>
                            );
                        })}
                    </ul>
                </div>
                <div className="completion-footer">
                    <div className="completion-down-arrow"></div>
                    <div className="completion-buttons">
                        <button className="kyc-checklist-btn">KYC Checklist</button>
                        <button className="decision-tree-btn" onClick={() => navigate('/decision-tree')}>Decision Tree</button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="screen-flow-container">
            <div className="header">
                <span className="logo">Demo</span>
                <h2>User Interface Screen Flow</h2>
                <span className="logo-end">KYC Requirements</span>
            </div>
            <div className="navigation-controls">
                {activeQuestion > 1 && activeQuestion <= maxQuestionId && (
                    <button onClick={handleBack} className="back-btn-global">Back</button>
                )}
            </div>
            <div className="question-display-area">
                {renderStepContent()}
            </div>
        </div>
    );
};

const QuestionCard = ({ question, onAnswer, answers, onMultiSelectAnswer, onAdvance, activeQuestion, kiwiId, setKiwiId, onSubmitKiwi }) => {
    const isAnswered = !!answers[question.id];
    const isDisabled = question.id !== activeQuestion;

    const handleMultiSelect = (option) => {
        const currentSelection = answers[question.id] || [];

        const newSelection = currentSelection.includes(option)
            ? currentSelection.filter(item => item !== option)
            : [...currentSelection, option];

        onMultiSelectAnswer(question.id, newSelection);
    };

    const renderInput = () => {
        switch (question.type) {
            case 'radio':
                return (
                    <div className={`options-container ${question.highlight ? 'radio-highlight' : ''}`}>
                        {question.options.map(option => (
                            <div key={option} className="radio-option">
                                <input
                                    type="radio"
                                    id={`q${question.id}-${option.replace(/\s/g, '-')}`}
                                    name={`question-${question.id}`}
                                    value={option}
                                    onChange={() => onAnswer(question.id, option)}
                                    checked={answers[question.id] === option}
                                    disabled={isDisabled}
                                />
                                <label htmlFor={`q${question.id}-${option.replace(/\s/g, '-')}`}>{option}</label>
                            </div>
                        ))}
                    </div>
                );
            case 'text':
                return (
                    <div className="text-input-container">
                        <input
                            type="text"
                            className={`text-input ${isAnswered ? 'answered' : ''}`}
                            placeholder="Manually Enter"
                            value={kiwiId}
                            onChange={(e) => setKiwiId(e.target.value)}
                            disabled={isDisabled}
                        />
                        <button className="continue-btn" onClick={onSubmitKiwi} disabled={!kiwiId.trim() || isAnswered}>Continue</button>
                    </div>
                );
            case 'dropdown':
                return (
                    <div className="qs-input-container">
                        <select
                            className={`dropdown-select ${answers[question.id] ? 'answered' : ''}`}

                            value={answers[question.id] || ''}
                            onChange={(e) => onAnswer(question.id, e.target.value)}
                            disabled={question.id !== activeQuestion}
                        >
                            <option value="" disabled>
                                {question.placeholder}
                            </option>

                            {question.options.map(opt => (
                                <option key={opt} value={opt}>{opt}</option>
                            ))}
                        </select>
                    </div>
                );
            case 'check-list':
                const selection = answers[question.id] || [];
                return (
                    <div className="checklist-wrapper">
                        <div className="checklist-container">
                            {question.options.map(option => (
                                <label key={option} className="checklist-item">
                                    <input
                                        type="checkbox"
                                        checked={selection.includes(option)}
                                        onChange={() => handleMultiSelect(option)}
                                        disabled={isDisabled}
                                    />
                                    <span className="checklist-label-text">{option}</span>
                                </label>
                            ))}
                        </div>
                        {selection.length > 0 && !isDisabled && (
                            <button
                                className="continue-btn checklist-next-btn"
                                onClick={onAdvance}
                            >
                                Next
                            </button>
                        )}
                    </div>
                );
            case 'business-relationship':
                return (
                    <div className="business-relationship-container">
                        <div className="relationship-option-row">
                            <div
                                className={`relationship-button client-button ${answers[question.id] === 'Client' ? 'selected' : ''}`}
                                onClick={() => !isDisabled && onAnswer(question.id, 'Client')}
                            >
                                Client
                            </div>
                            <div className="relationship-description">
                                A client is a legal person or a legal arrangement to whom CIB CACIB provides a service or sells products as part of a business relationship.
                            </div>
                        </div>
                        <div
                            className={`relationship-button non-client-button ${answers[question.id] === 'Non-Client' ? 'selected' : ''}`}
                            onClick={() => !isDisabled && onAnswer(question.id, 'Non-Client')}
                        >
                            Non-Client
                        </div>
                    </div>
                );

            case 'static-display':
                return (
                    <div className="static-display-with-button-container">
                        <div className='static-display-container'>
                            {question.fields.map((field, index) => (
                                <div key={index} className="static-field">
                                    {field}
                                </div>
                            ))}
                        </div>
                        <button className='btn static-next-btn' onClick={() => onAnswer(question.id, 'Viewed')} disabled={isDisabled}>Next</button>
                    </div>

                );
            case 'button-list':
                return (
                    <div className="button-list-container">
                        {question.options.map(option => (
                            <div
                                key={option}
                                className={`button-list-item ${answers[question.id] === option ? 'selected' : ''}`}
                                onClick={() => !isDisabled && onAnswer(question.id, option)}
                            >
                                {option}
                            </div>
                        ))}
                    </div>
                );
            case 'button-list-new':
                const isMulti = !!question.multiSelect;
                const currentAnswers = answers[question.id] || [];
                const wrapperClass = question.type === 'check-list' ? 'checklist-wrapper' : 'button-list-wrapper';
                const containerClass = question.type === 'check-list' ? 'checklist-container' : `button-list-container ${isMulti ? 'grid-layout' : ''}`;
                const itemClass = question.type === 'check-list' ? 'checklist-item' : 'button-list-item';

                return (
                    <div className={wrapperClass}>
                        <div className={containerClass}>
                            {question.options.map(option => (
                                <div
                                    key={option}
                                    className={`${itemClass} ${currentAnswers.includes(option) ? 'selected' : ''}`}
                                    onClick={() => !isDisabled && (isMulti ? handleMultiSelect(option) : onAnswer(question.id, option))}
                                >
                                    {question.type === 'check-list' && <input type="checkbox" readOnly checked={currentAnswers.includes(option)} />}
                                    {option}
                                </div>
                            ))}
                        </div>
                        {isMulti && currentAnswers.length > 0 && !isDisabled && (
                            <button
                                className="continue-btn multi-select-next-btn"
                                onClick={onAdvance}
                            >
                                Next
                            </button>
                        )}
                    </div>
                );
            default:
                return null;
        }
    };

    return (
        <div className={`question-box ${isAnswered ? 'answered' : ''} ${isDisabled ? 'disabled-card' : ''}`}>
            <h3> {question.title}</h3>
            {renderInput()}
        </div>
    );
};

function getStepForQuestion(questionId, allQuestions) {
    const question = allQuestions.find(q => q.id === questionId);
    return question ? question.step : Math.max(...allQuestions.map(q => q.step)) + 1;
}

const getAllQuestions = () => {
    return [
        { id: 1, step: 1, tabTitle: 'Process', title: 'What Process are you launching?', type: 'radio', options: ['Onboarding', 'Periodic Review'] },
        { id: 2, step: 1, tabTitle: 'Kiwis', title: 'Is the Entity Already in Kiwis?', type: 'radio', options: ['Yes', 'No'] },
        { id: 3, step: 1, tabTitle: 'Kiwis ID', title: 'What is Kiwis ID?', type: 'text' },
        {
            id: 4, step: 2, tabTitle: 'Business Relationship', title: 'What is the nature of Business Relationship?',
            type: 'business-relationship'
        },
        {
            id: 5, step: 2, tabTitle: 'Counter Party Family', title: 'Select Counter Party Family', type: 'check-list',
            options: ['Private Entity', 'SPV', 'Financial Institution', 'Fund', 'Trust', 'Fiducy', 'Family Holding', 'Supernational Entity',
                'Public Organization ', 'State Ownerd Enterprise (SOE)']
        },
        {
            id: 6, step: 2, tabTitle: 'Private Entities', title: 'Private Corporate', type: 'check-list', options: ['Private Corporate',
                'Co-operative', 'Partnership', 'Association', 'Non-Profit Charity', 'Foundation', 'Offshore Company']
        },
        { id: 7, step: 3, tabTitle: 'CACIB Group ', title: 'Is the entity part of CACIB Group?', type: 'radio', highlight: true, options: ['YES', 'NO', 'I Don\'t Know'] },
        { id: 8, step: 3, tabTitle: 'Client Involvement in specific activities', title: 'Is the client involve in any of the activity sector below?', type: 'button-list', options: ['None of the below', 'Mining and Extraction Industry', 'Casino and Gambling', 'Large Infrastructure Project', 'Trading in Diamon and Precious Stone', 'Trading in Works of Arts', 'Defense', ' Money Changers', ' Payment Services Provider (PSP) ', ' Distribution  of financialproducts ', ' Correspondent Banking '] },
        { id: 9, step: 4, tabTitle: 'Country of Registration & Incorporation', title: 'Select the country of registration/incorporation', type: 'dropdown', placeholder: 'Select from Below List', options: ['France'] },
        { id: 10, step: 4, tabTitle: 'Country risk tiering', title: 'Country risk tiering', type: 'static-display', fields: ['France', 'TIER 1'] },
        {
            id: 11, step: 5, tabTitle: 'CACIB Business Relationship',
            title: 'Select all the countries where CACIB has a business relationship with the client (WRM coverage, booking or selling)',
            type: 'button-list-new',
            multiSelect: true,
            options: ['Australia', 'Brazil', 'Canada', 'China', 'Denmark', 'Finland', 'France', 'Germany', 'HK', 'India', 'Italy', 'Japan', 'Korea', 'Qatar', 'United Kingdom', 'United States']
        },
        { id: 12, step: 6, tabTitle: 'Listing', title: 'Is the Client listed on an Exchange?', type: 'radio', highlight: true, options: ['Yes', 'it is a subsidiary owned at more than 75% of a listed entity', 'it is a subsidiary owned at less than 75% of a listed entity', 'No', 'I Don\'t Know'] },
        { id: 13, step: 6, tabTitle: 'Regulated', title: 'Is the Entity Regulated? ', type: 'radio', highlight: true, options: ['Yes', 'No', 'I Don\'t Know'] },
        { id: 14, step: 6, tabTitle: 'Client of Credit Agricole Group ', title: 'Is the entity already client of Credit Agricole Group?', type: 'radio', highlight: true, options: ['Yes', 'No', 'I Don\'t Know'] },
        {
            id: 15, step: 7, tabTitle: 'Country Risk', title: 'Is the Client working with/in one of the country below', type: 'dropdown', placeholder: 'Select from Below List',
            options: ["No", "I don't know", "Afghanistan", "Belarus", "Central African Republic", "Cuba", "Democratic Republic of Congo",
                "Eritrea", "Ethiopia", "Haiti", "Iran", "Lebanon", "Libya", "Myanmar", "Nicaragua", "North Korea", "Russia", "Somalia",
                "South Sudan", "Sudan", "Syria", "Ukraine (Russian-occupied regions only)", "Venezuela", "Yemen", "Zimbabwe"]
        },
        { id: 16, step: 7, tabTitle: 'Country Risk', title: 'Are the country of Incorporation, establishment, tax and mailing address, control & regulation same', type: 'radio', highlight: true, options: ['Yes', 'No', 'I Don\'t Know'] },
        {
            id: 17, step: 8, tabTitle: 'Country Risk', title: 'Is the intermediate Parent Company based in one of the country below', type: 'button-list',
            options: ["There is no parent company", "No", "I don't know", "Afghanistan", "Algeria", "Angola", "Belarus", "Bolivia", "Bulgaria",
                "Burkina Faso", "Cameroon", "Central African Republic", "Côte d'Ivoire", "Cuba", "Democratic Republic of the Congo", "Eritrea",
                "Ethiopia", "Haiti", "Iran", "Kenya", "Yemen", "Zimbabwe", "Laos", "Lebanon", "Libya", "Monaco", "Mozambique", "Myanmar", "Namibia",
                "Nepal", "Nicaragua", "Nigeria", "North Korea", "Russia", "Somalia", "South Africa", "South Sudan", "Sudan", "Syria", "Ukraine",
                "Venezuela", "Vietnam", "Virgin Islands (UK)"]
        },
        { id: 18, step: 9, tabTitle: 'Business Intermediary', title: 'Was the client introduced by a business intermediary or third party introducer?', type: 'radio', highlight: true, options: ['Yes', 'No'] },
        { id: 19, step: 9, tabTitle: 'PEP', title: 'Are you aware of any Politically Exposed Person (PEP) in the client ownership or management?', type: 'radio', highlight: true, options: ['Yes', 'No'] },
        { id: 20, step: 10, tabTitle: 'Additional Risk', title: 'Are you aware of any adverse media issues, sanction or compliance issues with the client?', type: 'radio', highlight: true, options: ['Yes', 'No'] },
    ];
};

export default UserFlow;
