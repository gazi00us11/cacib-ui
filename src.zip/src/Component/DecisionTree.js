import React, { useState, useEffect } from 'react';
import Tree from 'react-d3-tree';
import CustomDropdown from './CustomDropdown';
import { useNavigate } from 'react-router-dom';


const boxWidth = 250;
const boxHeight = 120;

const DecisionTree = () => {
  const navigate = useNavigate();
  const [scenarioData, setScenarioData] = useState({});
  const [scenarioOptions, setScenarioOptions] = useState([]);
  const [selectedScenario, setSelectedScenario] = useState('');

  const [decisionTreeOptions, setDecisionTreeOptions] = useState([]);
  const [selectedDecisionTree, setSelectedDecisionTree] = useState('');

  const [treeKeyMap, setTreeKeyMap] = useState({});

  const [scenarioText, setScenarioText] = useState('');
  const [selectedTime, setSelectedTime] = useState('');

  // Data loading logic remains the same
  useEffect(() => {
    const requireContext = require.context('../Data', false, /\.json$/);
    const loadedScenarios = {};

    requireContext.keys().forEach(filePath => {
      const treeKey = filePath.replace('./', '').replace('.json', '');
      const match = treeKey.match(/\d+/);
      const scenarioNumber = match ? match[0] : '1';
      const scenarioGroupKey = `Scenario ${scenarioNumber}`;

      if (!loadedScenarios[scenarioGroupKey]) {
        loadedScenarios[scenarioGroupKey] = {};
      }

      loadedScenarios[scenarioGroupKey][treeKey] = requireContext(filePath);
    });

    const sortedScenarioKeys = Object.keys(loadedScenarios).sort((a, b) => {
      const numA = parseInt(a.split(' ')[1], 10);
      const numB = parseInt(b.split(' ')[1], 10);
      return numA - numB;
    });

    setScenarioData(loadedScenarios);
    setScenarioOptions(sortedScenarioKeys);
  }, []);

  // Event handlers remain the same
  const handleScenarioChange = (value) => {
    setSelectedScenario(value);
    setSelectedDecisionTree('');
    setDecisionTreeOptions([]);
    setTreeKeyMap({});
    setSelectedTime('');
    setScenarioText('');

    if (value) {
      const rawTreeKeys = Object.keys(scenarioData[value]).sort();
      const newKeyMap = {};
      const friendlyOptions = rawTreeKeys.map((key, index) => {
        const friendlyName = `Decision Tree-${index + 1}`;
        newKeyMap[friendlyName] = key;
        return friendlyName;
      });

      setDecisionTreeOptions(friendlyOptions);
      setTreeKeyMap(newKeyMap);
      setScenarioText(`${value} - KYC Process Tree`);
    }
  };

  const handleDecisionTreeChange = (value) => {
    setSelectedDecisionTree(value);
    if (value) {
      setSelectedTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    } else {
      setSelectedTime('');
    }
  };

  const renderCustomNodeElement = ({ nodeDatum }) => (
    <g>
      <rect
        x={-boxWidth / 2}
        y={-boxHeight / 2}
        width={boxWidth}
        height={boxHeight}
        fill="white"
        stroke="black"
        strokeWidth="2"
        rx="10"
        ry="10"
      />
      <foreignObject
        x={-boxWidth / 2}
        y={-boxHeight / 2}
        width={boxWidth}
        height={boxHeight}
      >
        <div style={{
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
          height: '100%', padding: 10, textAlign: 'center', boxSizing: 'border-box'
        }}>
          <span style={{ fontSize: '16px', fontWeight: 'bold', marginBottom: 6 }}>
            {nodeDatum.name}
          </span>
          {nodeDatum.description && nodeDatum.description.trim() !== '' && (
            <span style={{
              fontSize: '13px', color: '#000', marginBottom: 0, background: 'lightblue',
              padding: '3px 8px', borderRadius: '5px'
            }}>
              {nodeDatum.description}
            </span>
          )}
          {nodeDatum.requirements && nodeDatum.requirements.trim() !== '' && (
            <span style={{
              fontSize: '12px', color: '#000', background: 'yellow',
              padding: '3px 8px', borderRadius: '5px',
            }}>
              {nodeDatum.requirements}
            </span>
          )}
        </div>
      </foreignObject>
    </g>
  );

  return (
    <div style={pageWrapper}>
      <div style={navigationControls}>
        <button onClick={()=>navigate('/')} style={backBtnGlobal}>Home</button>
      </div>
      <div style={controlColumnStyle}>
        <div style={controlGroup}>
          <label style={controlLabel}>Scenario</label>
          <CustomDropdown
            options={scenarioOptions}
            selectedValue={selectedScenario}
            onChange={handleScenarioChange}
            placeholder="Select Scenario"
          />
        </div>

        {selectedScenario && (
          <div style={infoBoxContainer}>
            <div style={infoBoxHeaderStyle}>Scenario</div>
            <div style={infoBoxTextStyle}>{scenarioText}</div>
          </div>
        )}


        {selectedScenario && (
          <div style={controlGroup}>
            <label style={controlLabel}>Decision Tree</label>
            <CustomDropdown
              options={decisionTreeOptions}
              selectedValue={selectedDecisionTree}
              onChange={handleDecisionTreeChange}
              placeholder="Select Decision Tree"
            />
          </div>
        )}

        {selectedTime && (
          <div style={infoBoxContainer}>
            <div style={infoBoxHeaderStyle}>Generated Time</div>
            <div style={infoBoxTextStyle}>{selectedTime}</div>
          </div>
        )}
      </div>



      {/* --- Column 3: Decision Tree Visualization --- */}

      {selectedDecisionTree && (
        <div style={treeColumnStyle}>

          <div style={headerWrapper}>
            <div style={headerTextStyle}>Decision Tree Visualization</div>
          </div>
          <div style={containerStyles}>
            <Tree
              data={scenarioData[selectedScenario][treeKeyMap[selectedDecisionTree]]}
              orientation="vertical"
              translate={{ x: 100, y: 150 }} // Adjusted translate for new column
              pathFunc="elbow"
              separation={{ siblings: 2, nonSiblings: 2 }}
              nodeSize={{ x: 280, y: 150 }}
              renderCustomNodeElement={renderCustomNodeElement}
            />
          </div>
        </div>
      )}
    </div>

  );
};

// --- STYLES (UPDATED FOR 3-COLUMN LAYOUT) ---
const pageWrapper = {
  display: 'flex',
  fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  backgroundColor: '#f0f2f5',
  minHeight: '100vh',
  alignItems: 'flex-start',
  padding: '20px',
  gap: '20px', // Adds space between the columns
};

const controlColumnStyle = {
  width: '100%',
  maxWidth: '350px',
  background: '#ffffff',
  borderRadius: '16px',
  padding: '28px',
  boxSizing: 'border-box',
  boxShadow: '0 8px 25px rgba(0, 0, 0, 0.1)',
  display: 'flex',
  flexDirection: 'column',
  gap: '24px',
  height: 'fit-content', // Column height will be based on its content
};

const treeColumnStyle = {
  flex: 1, // Allows this column to take up the remaining space
  position: 'relative',
  background: '#ffffff',
  borderRadius: '16px',
  padding: '24px',
  boxSizing: 'border-box',
  boxShadow: '0 8px 25px rgba(0, 0, 0, 0.1)',
  height: 'calc(100vh - 40px)', // Fills the vertical space minus padding
};

const containerStyles = {
  width: '100%',
  height: '100%',
};

const headerWrapper = {
  width: '100%',
  padding: '0 0 20px 0',
  boxSizing: 'border-box',
};

const headerTextStyle = {
  fontSize: '24px',
  fontWeight: 'bold',
  color: '#2a2a2a',
  textAlign: 'center',
};

const infoBoxContainer = {
  padding: '10px 15px',
  backgroundColor: '#f7f7fa',
  borderRadius: '8px',
  borderLeft: '4px solid #007bff',
};

const infoBoxHeaderStyle = {
  fontSize: '16px',
  fontWeight: '600',
  color: '#007bff',
  marginBottom: '8px',
};

const infoBoxTextStyle = {
  fontSize: '15px',
  color: '#555',
  lineHeight: '1.5',
};

const controlGroup = {
  display: 'flex',
  flexDirection: 'column',
  gap: '8px',
};

const controlLabel = {
  fontSize: '16px',
  fontWeight: '600',
  color: '#333',
};
const navigationControls = {
  height: '40px',
  marginBottom: '1rem',
};

const backBtnGlobal = {
  background: 'transparent',
  border: '1px solid #ddd', // Using fallback for var(--border-color)
  borderRadius: '8px',
  fontSize: '1rem',
  color: '#007bff', // Using fallback for var(--primary-blue)
  fontWeight: '600',
  cursor: 'pointer',
  padding: '0.5rem 1.2rem',
  transition: 'all 0.2s ease',
  display: 'inline-flex',
  alignItems: 'center',
};
export default DecisionTree;