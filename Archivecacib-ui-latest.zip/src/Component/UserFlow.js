import React, { useState, useEffect } from 'react';
import './UserFlow.css';
import { useNavigate } from 'react-router-dom';


// --- Static Data ---
const relevantEntityMapping = {
    'Private Entity': ['Private Corporate', 'Co-operative', 'Partnership', 'Association', 'Non-Profit Charity', 'Foundation', 'Offshore Company'],
    'SPV': ['Special purpose vehicles (SPV)', 'Special purpose company (SPC)', 'Asset back securities'],
    'Financial Institution': ['Bank', 'Branch of a bank', 'Insurance company', 'Asset manager', 'Other Financial institution (trading platform, etc)'],
    'Fund': ['Pension Fund', 'Pension trust entity', 'Traditional and non-alternative fund', 'Alternative fund management', 'Asset backed securities - securitization'],
    'Trust': ['Trust'],
    'Fiduciary': ['Fiduciary'],
    'Family Holding': ['Family Holding'],
    'Supranational Entity': ['Supranational entity'],
    'Public Organization': ['Central bank', 'Sovereign state', 'Ministry', 'State', 'Embassy', 'Territorial or local authority', 'Sovereign wealth fund', 'Agency (export credit, entity managing social benefits...)'],
    'State Owned Enterprise (SOE)': ['State-owned enterprise (SOE)'],
};

const getAllQuestions = () => [
    { id: 1, step: 1, tabTitle: 'Process', title: 'What Process are you launching?', type: 'radio', options: ['Onboarding', 'Periodic Review'] },
    { id: 2, step: 1, tabTitle: 'Counter Party Family', title: 'Select Counter Party Family', type: 'check-list', multiSelect: true, options: Object.keys(relevantEntityMapping) },
    { id: 3, step: 1, tabTitle: 'Relevant Entity', title: 'Relevant Entity', type: 'check-list', multiSelect: true, optionsSource: 'questionId:2' },
    { id: 4, step: 2, tabTitle: 'Country of Registration & Incorporation', title: 'Select the country of registration/incorporation', type: 'dropdown', placeholder: 'Select from below list', options: ['France' , 'USA', 'UK'] },
    { id: 5, step: 3, tabTitle: 'CACIB Business Relationship', title: 'Select all the countries where CACIB has a business relationship with the client (NRM coverage, booking or selling).', type: 'button-list-new', multiSelect: true, options: ['Australia', 'Brazil', 'Canada', 'China', 'Denmark', 'Finland', 'France', 'Germany', 'HK', 'India', 'Italy', 'Japan', 'Korea', 'Qatar', 'United Kingdom', 'United States'] },
    { id: 6, step: 4, tabTitle: 'Risk factor', title: 'Select the relevant risk factor', type: 'button-list-new', multiSelect: true, options: ['PEP', 'Listed in an acceptable regulated market', 'No listing', 'PEP unspecified', 'N/A'] }
];

// --- Main Component ---
export default function UserFlow() {
    const navigate = useNavigate();
    const [activeQuestion, setActiveQuestion] = useState(1);
    const [answers, setAnswers] = useState({});
    const allQuestions = getAllQuestions();
    const maxQuestionId = Math.max(...allQuestions.map(q => q.id));

    // --- Event Handlers ---
    const onAnswer = (id, answer) => {
        setAnswers(prev => ({ ...prev, [id]: answer }));
        if (id < maxQuestionId) {
            setActiveQuestion(id + 1);
        }
    };

    const advanceToNextQuestion = () => {
        const nextQuestion = allQuestions.find(q => q.id > activeQuestion);
        setActiveQuestion(nextQuestion ? nextQuestion.id : maxQuestionId + 1);
    };

    const handleMultiSelectAnswer = (id, option) => {
        setAnswers(prev => {
            const currentSelection = prev[id] || [];
            const newSelection = currentSelection.includes(option)
                ? currentSelection.filter(item => item !== option)
                : [...currentSelection, option];

            const newAnswers = { ...prev, [id]: newSelection };

            return newAnswers;
        });
    };

    const handleBack = () => {
        if (activeQuestion <= 1) return;
        const prevQuestionId = activeQuestion - 1;
        const { [activeQuestion]: _, ...remainingAnswers } = answers;
        setAnswers(remainingAnswers);
        setActiveQuestion(prevQuestionId);
    };

    const handleHome = () => {
        setAnswers({});
        setActiveQuestion(1);
    };

    const getCurrentStep = () => {
        const currentQ = allQuestions.find(q => q.id === activeQuestion);
        return currentQ ? currentQ.step : 1;
    };


    const currentStep = getCurrentStep();
    const questionsForCurrentStep = allQuestions.filter(q => q.step === currentStep);

    // --- Dynamic Options Logic ---
    const questionsWithDynamicOptions = questionsForCurrentStep.map(q => {
        if (q.id === 3) {
            const selectedFamilies = answers[2] || [];
            const dynamicOptions = Array.from(new Set(selectedFamilies.flatMap(family => relevantEntityMapping[family] || [])));
            return { ...q, options: dynamicOptions };
        }
        return q;
    });

    const renderStepCounter = () => {
        return (
            <div className="step-container single-view-fade-in">
                {questionsWithDynamicOptions.map((q, index) => (
                    <React.Fragment key={q.id}>
                        {index > 0 && activeQuestion >= q.id && <div className="step1-flow-arrow"></div>}
                        {activeQuestion >= q.id && (
                            <div className={`question-wrapper ${q.layout === 'full-width-grid' ? 'full-width-wrapper' : ''}`}>
                                <div className="box-title-tab">{q.tabTitle}</div>
                                <QuestionCard
                                    question={q}
                                    onAnswer={onAnswer}
                                    onMultiSelectAnswer={handleMultiSelectAnswer}
                                    onAdvance={advanceToNextQuestion}
                                    answers={answers}
                                    activeQuestion={activeQuestion}
                                />
                            </div>
                        )}
                    </React.Fragment>
                ))}
            </div>
        );
    }

    
    if (activeQuestion > maxQuestionId) {
        return (
            <div className="completion-page-container single-view-fade-in">
                <div className="navigation-controls">
                    <button onClick={handleBack} className="back-btn-global">Back</button>
                    <button onClick={handleHome} className="back-btn-global">Home</button>
                </div>

                <div className="completion-header">
                    Below are the list of selection made
                </div>
                <div className="completion-answers-container">
                    <ul className="completion-list">
                        {Object.entries(answers).sort(([a], [b]) => a - b).map(([qId, ans]) => {
                            const question = allQuestions.find(q => q.id === parseInt(qId));
                            const answerText = Array.isArray(ans) ? ans.join(', ') : ans;
                            return (
                                <li key={qId} className="completion-list-item">
                                    <strong>{question.title}:</strong> {answerText}
                                </li>
                            );
                        })}
                    </ul>
                </div>
                <div className="completion-footer">
                    <div className="completion-down-arrow"></div>
                    <div className="completion-buttons">
                        {/* <button className="kyc-checklist-btn">KYC Checklist</button> */}
                        {/* <button className="decision-tree-btn" onClick={() => navigate('/decision-tree')}>Decision Tree Visualization</button> */}
                        <button className="decision-tree-btn" onClick={() => navigate('/questionnaire')}>Decision Tree Visualization</button>
                    </div>
                </div>
            </div>
        );
    }


    return (
        <div className="screen-flow-container">
            <div className="header">
                <span className="logo">Demo</span>
                <h2>User Interface Screen Flow</h2>
                <span className="logo-end">KYC Requirements</span>
            </div>
            <div className="navigation-controls">
                {activeQuestion > 1 && activeQuestion <= maxQuestionId && (
                    <button onClick={handleBack} className="back-btn-global">Back</button>
                )}
            </div>
            <div className="question-display-area">
                {renderStepCounter()}
            </div>
        </div>
    );
}


// --- Child Components ---
const QuestionCard = ({ question, onAnswer, onMultiSelectAnswer, onAdvance, answers, activeQuestion }) => {
    const isAnswered = answers.hasOwnProperty(question.id);
    const isDisabled = question.id !== activeQuestion;

    const renderInput = () => {
        switch (question.type) {
            case 'radio':
                return (
                    <div className="options-container">
                        {question.options.map(option => (
                            <div key={option} className="radio-option">
                                <input
                                    type="radio"
                                    id={`${question.id}-${option}`}
                                    name={`question-${question.id}`}
                                    value={option}
                                    checked={answers[question.id] === option}
                                    onChange={() => onAnswer(question.id, option)}
                                    disabled={isDisabled}
                                />
                                <label htmlFor={`${question.id}-${option}`}>{option}</label>
                            </div>
                        ))}
                    </div>
                );
            case 'dropdown':
                return (
                    <div className="qs-input-container">
                        <select
                            className={`dropdown-select ${answers[question.id] ? 'answered' : ''}`}

                            value={answers[question.id] || ''}
                            onChange={(e) => onAnswer(question.id, e.target.value)}
                            disabled={question.id !== activeQuestion}
                        >
                            <option value="" disabled>
                                {question.placeholder}
                            </option>

                            {question.options.map(opt => (
                                <option key={opt} value={opt}>{opt}</option>
                            ))}
                        </select>
                    </div>
                );

            case 'check-list':
                const selection = answers[question.id] || [];
                if (question.id === 3 && (!question.options || question.options.length === 0)) {
                    return <p>Please select a Counter Party Family to see relevant options.</p>;
                }
                return (
                    <div className="checklist-wrapper">
                        <div className="checklist-container">
                            {question.options.map(option => (
                                <div key={option} className="checklist-item">
                                    <input
                                        type="checkbox"
                                        id={option}
                                        checked={selection.includes(option)}
                                        onChange={() => onMultiSelectAnswer(question.id, option)}
                                        disabled={isDisabled}
                                    />
                                    <label htmlFor={option}><span>{option}</span></label>
                                </div>
                            ))}
                        </div>
                        {selection.length > 0 && !isDisabled && (
                            <button className="continue-btn multi-select-next-btn" onClick={onAdvance}>
                                Next
                            </button>
                        )}
                    </div>
                );
            case 'business-relationship':
                return (
                    <div className="business-relationship-container">
                        <div className="relationship-option-row">
                            <div
                                className={`relationship-button client-button ${answers[question.id] === 'Client' ? 'selected' : ''}`}
                                onClick={() => !isDisabled && onAnswer(question.id, 'Client')}
                            >
                                Client
                            </div>
                            <div className="relationship-description">
                                A client is a legal person or a legal arrangement to whom CIB CACIB provides a service or sells products as part of a business relationship.
                            </div>
                        </div>
                        <div
                            className={`relationship-button non-client-button ${answers[question.id] === 'Non-Client' ? 'selected' : ''}`}
                            onClick={() => !isDisabled && onAnswer(question.id, 'Non-Client')}
                        >
                            Non-Client
                        </div>
                    </div>
                );

            case 'static-display':
                return (
                    <div className="static-display-with-button-container">
                        <div className='static-display-container'>
                            {question.fields.map((field, index) => (
                                <div key={index} className="static-field">
                                    {field}
                                </div>
                            ))}
                        </div>
                        <button className='btn static-next-btn' onClick={() => onAnswer(question.id, 'Viewed')} disabled={isDisabled}>Next</button>
                    </div>

                );
            case 'button-list':
                return (
                    <div className="button-list-container">
                        {question.options.map(option => (
                            <div
                                key={option}
                                className={`button-list-item ${answers[question.id] === option ? 'selected' : ''}`}
                                onClick={() => !isDisabled && onAnswer(question.id, option)}
                            >
                                {option}
                            </div>
                        ))}
                    </div>
                );
            case 'button-list-new':
                const isMulti = !!question.multiSelect;
                const currentAnswers = answers[question.id] || [];
                const wrapperClass = question.type === 'check-list' ? 'checklist-wrapper' : 'button-list-wrapper';
                const containerClass = question.type === 'check-list' ? 'checklist-container' : `button-list-container ${isMulti ? 'grid-layout' : ''}`;
                const itemClass = question.type === 'check-list' ? 'checklist-item' : 'button-list-item';

                return (
                    <div className={wrapperClass}>
                        <div className={containerClass}>
                            {question.options.map(option => (
                                <div
                                    key={option}
                                    className={`${itemClass} ${currentAnswers.includes(option) ? 'selected' : ''}`}
                                    onClick={() => !isDisabled && (isMulti ? onMultiSelectAnswer(question.id, option) : onAnswer(question.id, option))}
                                >
                                    {question.type === 'check-list' && <input type="checkbox" readOnly checked={currentAnswers.includes(option)} />}
                                    {option}
                                </div>
                            ))}
                        </div>
                        {isMulti && currentAnswers.length > 0 && !isDisabled && (
                            <button
                                className="continue-btn multi-select-next-btn"
                                onClick={onAdvance}
                            >
                                Next
                            </button>
                        )}
                    </div>
                );
            default:
                return <div>Unsupported question type: {question.type}</div>;
        }
    };

    return (
        <div className={`question-box ${isAnswered ? 'answered' : ''} ${isDisabled ? 'disabled-card' : ''}`}>
            <h3 className="question-title">{question.title}</h3>
            {renderInput()}
        </div>
    );
};
