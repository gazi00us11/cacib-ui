import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import './KYCChecklist.css';
import { useNavigate } from 'react-router-dom';

const nonConditionalQuestionsData = [
    {
        id: "non_cond_1",
        name: "Client Identification and Verification",
        description: "Collect and verify client identity information: Name, Address, Taxpayer Identification Number, and other acceptable documents.",
        type: "non_conditional",
    },
    {
        id: "non_cond_2",
        name: "Business Relationship Information",
        description: "Collect information on the purpose and intended nature of the business relationship, establishment channel, and products/services.",
        type: "non_conditional",
    },
    {
        id: "non_cond_3",
        name: "Geographic Information",
        description: "Identify countries linked to the client, including incorporation, establishment, tax residency, and mailing addresses.",
        type: "non_conditional",
    },
    {
        id: "non_cond_4",
        name: "Adverse Information Check",
        description: "Perform searches for relevant adverse information on the client, shareholders, UBOs, and legal representatives.",
        type: "non_conditional",
    }
];

const KYCChecklist = () => {
    const location = useLocation();
    const navigate = useNavigate();
    // This line now correctly receives the data from Questionnaire.js
    const answeredQuestions = location.state?.answeredQuestions || [];

    const [nonConditional, setNonConditional] = useState([]);

    useEffect(() => {
        setNonConditional(nonConditionalQuestionsData);
    }, []);

    const handleBack = () => {
        navigate('/questionnaire');
    };
    const handleHome = () => {
        navigate('/');
    }

    return (
        <div className="kyc-checklist-container single-view-fade-in">
             <div className="navigation-controls">
                <button onClick={handleHome} className="back-btn-global">
                    Home
                </button>
                <button onClick={handleBack} className="back-btn-global">
                    Back
                </button>
            </div>
            <div className="kyc-checklist-header">
                <h2>Completed KYC Checklist</h2>
                <p>A summary of your selections and required compliance steps.</p>
            </div>

            {/* This section will now display your answered questions */}
            <div className="answered-questions-section">
                <h3>Decision Tree Questionnaire</h3>
                {answeredQuestions.length > 0 ? (
                    <ul className="answers-list">
                        {answeredQuestions.map((item, index) => (
                            <li key={index} className="answer-item">
                                <span className="question-text">{item.question}</span>
                                <span className="answer-text">{item.requirement}</span>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p>No answers have been recorded.</p>
                )}
            </div>

            {/* Non-Conditional Section remains the same */}
            <div className="non-conditional-section">
                <h3>Non-Conditional Requirements</h3>
                <div className="non-conditional-table">
                    <div className="non-conditional-table-header">
                        <div className="header-cell">Question</div>
                        <div className="header-cell">Description</div>
                    </div>
                    {nonConditional.map((item) => (
                        <div key={item.id} className="non-conditional-row">
                            <div className="cell question-name">{item.name}</div>
                            <div className="cell question-description">{item.description}</div>
                        </div>
                    ))}
                </div>
            </div>
           

        </div>
    );
};

export default KYCChecklist;
